package br.edu.univs.calculadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoCalculadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoCalculadoraApplication.class, args);
	}

}
